1. delete venv taken from git repo
2. python3 -m venv venv (venv == name of venv)
3. .\venv\Scripts\activate 
4. streamlit run main.py